/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

import primero.Alojamientos;
import primero.Tipos;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author Mejias Gonzalez Francisco
 * @author Alvaro Perez Salvador
 * @author Andy Jan
 * @author Pablo Jimenez Fuentes
 */
public class CrudTipos {

	//@author Mejias Gonzalez Francisco
    public static boolean alta(BufferedReader teclado) {
        String descripcion;
        int numero;
        Session sesion = SessionFactoryUtil.getSessionFactory().openSession();
        Transaction tx = null;
        try {
            System.out.println("Introduce un numero de tipo: ");
            teclado = new BufferedReader(new InputStreamReader(System.in));
            numero = Integer.valueOf(teclado.readLine());
            if (numero <= 0) {
                System.out.println("Error: El codigo debe ser mayor que 0");
                return false;
            }
            Tipos tipoExistente = (Tipos) sesion.get(Tipos.class, numero);
            if (tipoExistente != null) {
                System.out.println("Error: Ya existe un tipo con ese codigo");
                return false;
            }
            System.out.println("Introduce una descripcion: ");
            descripcion = teclado.readLine();
            if (descripcion == null || descripcion.trim().isEmpty()) {
                System.out.println("Error: La descripcion no puede estar vacía");
                return false;
            }
            Query query = sesion.createQuery(
                    "SELECT COUNT(t) FROM primero.Tipos t WHERE t.descripcion = :desc");
            query.setParameter("desc", descripcion);
            Long count = (Long) query.uniqueResult();

            if (count > 0) {
                System.out.println("ERROR: Ya existe un tipo con esa descripcion.");
                return false;
            }
            tx = sesion.beginTransaction();
            Tipos tipo = new Tipos();
            tipo.setCodigo(numero);
            tipo.setDescripcion(descripcion);
            sesion.save(tipo);
            tx.commit();

            System.out.println("Alta correcta");
            return true;
        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            System.out.println("Error: " + e.getMessage());
            return false;
        } finally {
            sesion.close();
        }

    }

    //@author Mejias Gonzalez Francisco
    public static boolean baja(BufferedReader teclado) {
        try {
            String descripcion;
            int numero;
            Session sesion = SessionFactoryUtil.getSessionFactory().openSession();
            Transaction tx = null;
            // 1. Pedir codigo al usuario (usando BufferedReader como en alta)
            System.out.print("Ingrese el codigo a eliminar: ");
            int codigo = Integer.parseInt(teclado.readLine());


            try {
                // 2. Verificar que existe el registro
                Tipos tipo = (Tipos) sesion.get(Tipos.class, codigo);

                if (tipo == null) {
                    System.out.println("ERROR: No existe un tipo con ese codigo.");
                    return false;
                }

                // 3. Eliminar dentro de transaccion
                tx = sesion.beginTransaction();
                sesion.delete(tipo);
                tx.commit();

                System.out.println("Baja exitosa: Tipo eliminado.");
                return true;

            } catch (Exception e) {
                if (tx != null) {
                    tx.rollback();
                }
                System.out.println("ERROR: " + e.getMessage());
                return false;
            } finally {
                sesion.close();
            }
        } catch (IOException ex) {
            Logger.getLogger(CrudTipos.class.getName()).log(Level.SEVERE, null, ex);
            return false;
        }
    }

    //@author Pablo Jimenez Fuentes
    public static boolean modificar(BufferedReader teclado) {
        Session sesion = SessionFactoryUtil.getSessionFactory().openSession();
        Transaction tx = null;
        Tipos tipo = null;

        try {
            while (tipo == null) {
                System.out.print("Ingrese el codigo a modificar: ");
                try {
                    int codigo = Integer.parseInt(teclado.readLine());
                    tipo = (Tipos) sesion.get(Tipos.class, codigo);

                    if (tipo == null) {
                        System.out.println("ERROR: No existe un tipo con ese codigo. Inténtelo de nuevo.");
                    }
                } catch (NumberFormatException e) {
                    System.out.println("ERROR: Debe ingresar un número entero válido.");
                }
            }

            System.out.println("Descripción actual: " + tipo.getDescripcion());
            System.out.print("Ingrese la nueva descripción: ");
            String nuevaDescripcion = teclado.readLine();

            tx = sesion.beginTransaction();
            tipo.setDescripcion(nuevaDescripcion);
            tx.commit();

            System.out.println("Modificación exitosa.");
            return true;

        } catch (Exception e) {
            if (tx != null) {
                tx.rollback();
            }
            System.out.println("ERROR: " + e.getMessage());
            return false;
        } finally {
        	try {
				teclado.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
            sesion.close();
        }
    }
    //@author Andy Jan
    public static void resumenTipos(){
    	Session sesion = SessionFactoryUtil.getSessionFactory().openSession();
    	try{
    	List<Tipos> tipos = sesion.createQuery("FROM  primero.Tipos").list();
    	
    	for(Tipos tipo : tipos){

    		String consulta = "SELECT COUNT(a) FROM primero.Alojamientos a WHERE a.tipo = :codigo";
    		Long conteo = (Long) sesion.createQuery(consulta).setParameter("codigo", tipo.getCodigo()).uniqueResult();
    		
    		System.out.println(tipo.getDescripcion() + ": " + conteo);
    	}
    	} finally{
    		sesion.close();
    	}
    }
    
    /**
     * @author Alvaro Perez Salvador
     */
    public static void mostrarAlojamientosPorTipo(BufferedReader br) {
	    int codigoTipo = 0;
	    List<Alojamientos> lista;
	    String estado;
	    Tipos tipo;
	    Query query;
	    boolean leido = false;
	    Session session = null;
	    
	    try {
	    	session = SessionFactoryUtil.getSessionFactory().openSession();

	    	// Mostrar todos los tipos disponibles
	    	List<Tipos> listaTipos = session.createQuery("FROM Tipos").list();
	    	System.out.println("===== TIPOS DISPONIBLES =====");
	    	for (Tipos t : listaTipos) {
	    	    System.out.println("C�digo: " + t.getCodigo() + 
	    	                       " - Descripci�n: " + t.getDescripcion());
	    	}
	    	System.out.println("================================");

	        // Pedir c�digo del tipo
	        System.out.print("Introduce el c�digo del tipo: ");
	        while (!leido) {
	            try {
	                codigoTipo = Integer.parseInt(br.readLine());
	                leido = true;
	            } catch (NumberFormatException ex) {
	                System.out.print("Introduce un n�mero v�lido: ");
	            }
	        }
	        //Cogemos el tipo seg�n el codigo del tipo introducido por teclado
	        tipo = (Tipos) session.get(Tipos.class, codigoTipo);
	        if (tipo == null) {
	        	//Si es nulo es que no existe ese tipo
	            System.out.println("No existe ning�n tipo con ese c�digo.");
	        } else {
	        	//Si no es nulo mostramos el tipo seleccionado
	            System.out.println("Tipo seleccionado: " + tipo.getDescripcion());
	            System.out.println("--------------------------------------------------");
	            //Y hacemos una consulta para recoger todos los alojamientos con ese tipo(COMO PARAMETRO)
	            query = session.createQuery("FROM Alojamientos a WHERE a.tipo = :codigo");
	            //Cambiamos ese parametro por el introducido
	            query.setInteger("codigo", codigoTipo);
	            //Y sacamos la lista de alojamientos
	            lista = query.list();

	            if (lista.isEmpty()) {
	            	//Si la lista esta vacia es que ese tipo SI EXISTE pero no hay ningun alojamiento con ese tipo
	                System.out.println("No hay alojamientos de este tipo.");
	            } else {
	            	//Si no esta vacia la recorremos mostrando todo
	                for (Alojamientos a : lista) {
	                	if (a.getAlquilado()) {
	                	    estado = "Alquilado";
	                	} else {
	                	    estado = "Libre";
	                	}
	                    System.out.println("Nombre: " + a.getNombre());
	                    System.out.println("Estado: " + estado);
	                    System.out.println("--------------------------------------------------");
	                }
	            }
	        }

	    } catch (IOException e) {
	        System.out.println("Error de E/S.");
	    } finally {
	            session.close();   
	    }
	}
    
    public static void main (String args[]){
        BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
        int opcion = 0;
        boolean salir = false;
        boolean leido;
        String linea;
        try {
            while (!salir) {
                System.out.println("1.- Alta.");
                System.out.println("2.- Baja.");
                System.out.println("3.- Modificar descripci�n.");
                System.out.println("4.- Mostrar alojamientos por tipo.");
                System.out.println("5.- Mostrar resumen de tipo de alojamiento.");
                System.out.println("6.- Salir");
                System.out.print("Opci�n: ");
                leido = false;
                while (!leido) {
                    try {
                        linea = br.readLine();
                        opcion = Integer.parseInt(linea);
                        leido = true;
                    } catch (NumberFormatException e) {
                        System.out.print("Introduce un n�mero v�lido: ");
                    }
                }
                switch (opcion) {
                    case 1:
                        alta(br);
                        break;
                    case 2:
                        baja(br);
                        break;
                    case 3:
                        modificar(br);
                        break;
                    case 4:
                        mostrarAlojamientosPorTipo(br);
                        break;
                    case 5:
                        resumenTipos();
                        break;
                    case 6:
                        salir = true;
                        System.out.println("Saliendo del programa...");
                        break;
                    default:
                        System.out.println("Opci�n no v�lida.");
                }
                System.out.println();
            }
        } catch (IOException e) {
            System.out.println("Error de E/S.");
        } finally {
            try {
                br.close();
            } catch (IOException e) {
                System.out.println("Error al cerrar el lector.");
            }
        }
    } 
}
